package com.goott.eco.service;


public interface CompanyService {

}
