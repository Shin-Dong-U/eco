package com.goott.eco.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.goott.eco.mapper.CompanyMapper;

public class CompanyServiceImpl {//implements CompanyService{
	
//	@Autowired
//	private CompanyMapper compDao;



}
