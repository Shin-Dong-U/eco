package com.goott.eco.domain;

import java.sql.Timestamp;

public class PointVO {
	private Long point_seq;
	private String cust_id;
	private Long order_seq;
	private String reguser;
	private Timestamp regdate;
	private String edituser;
	private Timestamp editdate;
}
