package com.goott.eco.domain;

import lombok.Data;

@Data
public class CustAuthVO {
	private String memberId;
	private String auth;
}
